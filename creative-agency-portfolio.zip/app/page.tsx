import Hero from "./components/Hero"
import FeatureCarousel from "./components/FeatureCarousel"
import NewsletterSubscribe from "./components/NewsletterSubscribe"

export default function Home() {
  return (
    <>
      <Hero />
      <FeatureCarousel />
      <NewsletterSubscribe />
    </>
  )
}
