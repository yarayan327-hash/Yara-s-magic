"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ChevronDown, Mic, Folder, Settings, Link, Zap, Send } from "lucide-react"

export default function NewsletterSubscribe() {
  const [selectedModel, setSelectedModel] = useState("GPT-4")
  const [message, setMessage] = useState("")

  return (
    <section className="bg-background py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-8"
        >
          <h2 className="text-2xl font-bold text-foreground mb-4">Stay Inspired</h2>
          <p className="text-muted-foreground mb-8">Hey, Yara！I'm here to help with anything you need.</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          {/* Chat interface container */}
          <div className="bg-gradient-to-br from-primary/90 via-purple-600/80 to-primary rounded-2xl p-8 shadow-2xl border border-purple-400/30 min-h-[240px] flex flex-col justify-between">
            <div className="flex justify-start mb-4">
              <img src="/images/wizard-hat.png" alt="Wizard Hat" className="w-8 h-8 opacity-80" />
            </div>

            <div className="flex-1 flex items-center justify-center mb-6">
              <div className="w-full max-w-2xl">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-4">
                  <div className="flex items-center gap-3">
                    <input
                      type="text"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Type your message here..."
                      className="flex-1 bg-transparent text-white placeholder-white/60 border-none outline-none text-sm"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="rounded-full bg-white/20 hover:bg-white/30 text-white h-8 w-8"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-4">
              {/* Left side controls */}
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full bg-white/10 hover:bg-white/20 text-white h-12 w-12"
                >
                  <Settings className="h-5 w-5" />
                </Button>

                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full bg-white/10 hover:bg-white/20 text-white h-12 w-12"
                >
                  <Link className="h-5 w-5" />
                </Button>

                {/* Model selector dropdown */}
                <div className="relative">
                  <Button
                    variant="ghost"
                    className="rounded-full bg-black/20 hover:bg-black/30 text-white px-6 py-3 h-12 flex items-center gap-2 border border-white/20"
                  >
                    <Zap className="h-5 w-5 text-yellow-300" />
                    <span className="text-sm font-medium text-white">{selectedModel}</span>
                    <ChevronDown className="h-4 w-4 text-white" />
                  </Button>
                </div>
              </div>

              {/* Right side controls */}
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full bg-black/20 hover:bg-black/30 text-white h-12 w-12 border border-white/20"
                >
                  <Folder className="h-5 w-5" />
                </Button>

                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full bg-white hover:bg-white/90 text-primary h-12 w-12"
                >
                  <Mic className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
