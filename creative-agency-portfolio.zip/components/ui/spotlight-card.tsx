"use client"

import type React from "react"
import type { ReactNode } from "react"

interface GlowCardProps {
  children: ReactNode
  className?: string
  glowColor?: "blue" | "purple" | "green" | "red" | "orange"
  size?: "sm" | "md" | "lg"
  width?: string | number
  height?: string | number
  customSize?: boolean
}

const sizeMap = {
  sm: "w-48 h-64",
  md: "w-64 h-80",
  lg: "w-80 h-96",
}

const GlowCard: React.FC<GlowCardProps> = ({
  children,
  className = "",
  size = "md",
  width,
  height,
  customSize = false,
}) => {
  const getSizeClasses = () => {
    if (customSize) {
      return ""
    }
    return sizeMap[size]
  }

  const getInlineStyles = () => {
    const baseStyles: React.CSSProperties = {}

    if (width !== undefined) {
      baseStyles.width = typeof width === "number" ? `${width}px` : width
    }
    if (height !== undefined) {
      baseStyles.height = typeof height === "number" ? `${height}px` : height
    }

    return baseStyles
  }

  return (
    <div
      style={getInlineStyles()}
      className={`
        ${getSizeClasses()}
        ${!customSize ? "aspect-[3/4]" : ""}
        rounded-2xl 
        relative 
        grid 
        grid-rows-[1fr_auto] 
        shadow-lg
        p-4 
        gap-4 
        bg-gradient-to-br from-purple-100 to-purple-200
        border border-purple-200
        ${className}
      `}
    >
      {children}
    </div>
  )
}

export { GlowCard }
